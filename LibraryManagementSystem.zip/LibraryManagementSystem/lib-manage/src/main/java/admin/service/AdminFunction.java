package admin.service;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

@Path("admin")
public class AdminFunction{
	public static JSONObject library = new JSONObject(); 
	
	@GET
	@Path("add")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public Response addBook(String bookDetails){
		
		JSONObject newBook = new JSONObject(bookDetails);
		JSONObject response = new JSONObject();
	    library.put(newBook.getString("name"),newBook);
	   
	    //System.out.println(library.toString());
	    response.put("status", "Success");
		return Response.status(200).entity(response.toString()).build();
	}
	
	@GET
	@Path("remove")
	
	public Response removeBook(String bookName){
		
		JSONObject bookObject = new JSONObject(bookName);
		library.remove(bookObject.getString("name"));
		JSONObject response = new JSONObject();
		response.put("message","Book "+bookObject.getString("name")+" is Deleted");
		response.put("status","Success");
		//System.out.println(library.toString());
		return Response.status(200).entity(response.toString()).build();
	}
		

}

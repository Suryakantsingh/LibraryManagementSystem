package user.service;
import admin.service.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("user")
public class UserFunction {
	
	
	@GET
	@Path("list")
	public String  bookList(){
		
		JSONArray jsonarray = new JSONArray();
		Iterator itr =  AdminFunction.library.keys();
	    while(itr.hasNext()){
				String key = (String) itr.next();
				jsonarray.put(AdminFunction.library.get(key));
		}
		return jsonarray.toString();	
	}
	
	@GET
	@Path("sortbook")
    public String bookSort(String sortByOrder ){
		
		JSONArray jsonarray = new JSONArray();
		Iterator itr =  AdminFunction.library.keys();
	    while(itr.hasNext()){
				String key = (String) itr.next();
				jsonarray.put(AdminFunction.library.get(key));
		}
		
		final JSONObject sortingDetails = new JSONObject(sortByOrder);
		ArrayList<JSONObject> list = new ArrayList<JSONObject>();
		for(int i=0;i<jsonarray.length();i++){
			list.add(jsonarray.getJSONObject(i));
		}
		
		 JSONArray sortedArray = new JSONArray();
		
		Collections.sort(list, new Comparator<JSONObject>(){
		    public int compare(JSONObject a,JSONObject b){
				Object val1 = new Object();
				Object val2 = new Object();
				try{
					if(sortingDetails.getString("sortby").equals("name"))
					{
					val1 = (String) a.get(sortingDetails.getString("sortby"));
					val2 = (String) b.get(sortingDetails.getString("sortby"));
					
					if(sortingDetails.getString("sortmethod").equals("ascending")){
						return  ((String) val1).compareTo((String)val2);
					}else{
						if(sortingDetails.getString("sortmethod").equals("descending")){
							return -((String) val1).compareTo((String)val2);
						}
					}
					}else{
						if(sortingDetails.getString("sortby").equals("price"))
						{
							val1 = (Integer) a.get(sortingDetails.getString("sortby"));
							val2 = (Integer) b.get(sortingDetails.getString("sortby"));	
						}
						if(sortingDetails.getString("sortmethod").equals("ascending")){
							return  ((Integer) val1).compareTo((Integer)val2);
						}else{
							if(sortingDetails.getString("sortmethod").equals("descending")){
								return -((Integer) val1).compareTo((Integer)val2);
							}
						}
					}
				}catch(JSONException e){
					e.printStackTrace();
				}
				return 0;
			}
			
		});
		
		for(int j=0;j<jsonarray.length();j++){
			sortedArray.put(list.get(j));
		}
	 return sortedArray.toString();	
	}
	
	@GET
	@Path("search")
	public String searchBook(String searchDetails){
		JSONObject searchParam = new JSONObject(searchDetails);

		if(searchParam.getString("filterBy").equals("book name")){
			return AdminFunction.library.getJSONObject(searchParam.getString("name")).toString();
		}else{
		     
			if(searchParam.getString("filterBy").equals("author")){
		    	 Iterator itr =  AdminFunction.library.keys();
		 	     
		    	 while(itr.hasNext()){
		 				String key = (String) itr.next();
		 			    JSONObject libIterator = (JSONObject) AdminFunction.library.get(key);
		 			    if(libIterator.getString("author").equals(searchParam.getString("name"))){
		 			    	return libIterator.toString();
		 			    }
		 		}
		   }
	   }
		return "Not Found";
	}
	

}
